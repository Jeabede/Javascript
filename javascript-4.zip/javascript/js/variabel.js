let angka;

let kata = "saya belajar";

const data = 100;

angka = 5;

console.log(angka);
console.log(kata);

console.log(data);

angka = 8;
console.log(angka);

let isi = 4;
console.log(typeof isi);

isi = true;
console.log(typeof isi);

isi = "true";
console.log(typeof isi);

isi = '2';
console.log(typeof isi);

var a = 1;
console.log(typeof a);

a = 'a';
console.log(typeof a);