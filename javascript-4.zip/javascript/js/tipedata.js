let angka = 10;

let kata = "saya belajar javascript";

let pecahan = 2.5;

console.log(angka);

console.log(typeof kata);

console.log(1 / 0);

console.log("javascript" / 2 + 5);


let isi = 'Belajar';

console.log(isi + kata);

console.log(`'smk revit' ${angka} ${kata} ${isi}`);
console.log("smmk revit" + " " + angka + " " + kata + " " + isi);

let kondisi = false;
console.log(typeof kondisi);

let age = null;
console.log(typeof age);

let kosong;
console.log(typeof kosong);

let bigInt = 1234567890123456789012345678901234567890n;
console.log(typeof bigInt)
