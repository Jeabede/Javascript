document.querySelector("h1").innerText = "saya belajar javascript";
document.querySelector("p").innerText = "belajar javascript itu mudah";
document.querySelector(".isi").innerText = "saya belajar javascripts";
document.querySelector("#judul").innerText = "belajar js itu mudah";
document.querySelector("#foot").innerText = "contoh footer";
document.querySelector("#cont").innerText = "contoh isi footer";
