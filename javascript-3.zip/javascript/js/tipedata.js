let angka = 10;
let kata = "Saya Belajar Javascript";
let pecahan = 2.5;

console.log(angka);
console.log(typeof pecahan);
console.log(1 / 0);
console.log("Javascript" / 2 + 5);

let isi = "Belajar";

console.log(isi + kata);
console.log(`"SMKN 2 Buduran" ${angka} ${kata} ${isi}`);
console.log("SMKN 2 Buduran" + angka + kata + " " + isi);

let kondisi = true;

console.log(kondisi);

let age = null;

console.log(age);

let kosong;

console.log(kosong);