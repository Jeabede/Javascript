let angka;
let kata = "Saya Belajar";

const data = 100;

angka = 5;


console.log(angka);

console.log(kata);
console.log(data);

angka = 8;
console.log(angka);

let isi = 4.6;

console.log(typeof isi);