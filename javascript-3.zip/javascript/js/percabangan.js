if (true) {
    console.log("Dijalankan jika benar");
} else {
    console.log("Dijalankan jika salah");
}

let nilai = 100;
let kkm = 80;
let baik = "LULUS";
let buruk = "GAGAL";
let batasatas = 100;
let batasbawah = 0;
let peringatan = "Nilai Salah!"

if (nilai <= batasatas && nilai >= batasbawah) {
    if (nilai >= kkm) {
        console.log(baik);
    } else {
        console.log(buruk);
    }
} else {
    console.log(peringatan);
}