let a = true;
let b = false;
let c = true;
let d = false;

// OR
// Akan bernilai true jika salah satu true
console.log(d || b || a);

// AND
// Akan bernilai false jika salah satu false
console.log(a && b && c);

let x = 8;
let y = 7;

// Lebih Besar
console.log(x > y);

// Lebih Kecil
console.log(x < y);

// Sama Dengan
// sama isinya
console.log(x == y);

// Lebih Besar Sama Dengan
console.log(x >= y);

// Lebih Kecil Sama Dengan
console.log(x <= y);

let lima = "5";
let limo = 5;

// Identik - sama type data dan isi
console.log(lima === limo);