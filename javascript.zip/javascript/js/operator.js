let x = 2;
x = -x;

console.log(x);

let p = 5,
    l = 6,
    t = 7,
    volume;

// p = 5;
// l = 6;
// t = 7;

volume = p * l * t;

console.log(volume);
console.log(2 + 3);
console.log(2 - 3);
console.log(2 * 3);
console.log(3 / 2);
console.log(7 % 5);

let kota = "Sido" + "arjo";

console.log(kota);
console.log("1" + 5 + 6);
console.log(1 + 5 + "6");
console.log(5 - "3");
console.log("5" - 3);