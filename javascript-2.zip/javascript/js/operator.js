let x = 2;
x = -x;

console.log(x);

let p = 5,
    l = 6,
    t = 7,
    volume;

// p = 5;
// l = 6;
// t = 7;

volume = p * l * t;

console.log(volume);
console.log(2 + 3);
console.log(2 - 3);
console.log(2 * 3);
console.log(3 / 2);
console.log(7 % 5);

let kota = "Sido" + "arjo";

console.log(kota);
console.log("1" + 5 + 6);
console.log(1 + 5 + "6");

console.log(5 - "3");
console.log("5" - 3);

console.log("5" / "3");
console.log(5 / "3");
console.log("5" / 3);

console.log(4 ** 2);

let a, b, c;
a = b = c = 3 + 3;
console.log(b);

let inc = 5;
inc++;
console.log(inc);
inc--;

let dec = 2;
dec--;
console.log(dec);

let coba = (1 - 2, 2 + 1, 5 + 2);
console.log(coba);